datasets=('xsum' 'squad' 'writingprompts' 'pubmedqa' 'openreview' 'tweets' 'blog')
#operations=('create' 'rewrite' 'summary' 'refine' 'polish' 'expand' 'translate')
operation='translate'

for dataset in ${datasets[@]}; do
#  for operation in ${operations[@]}; do
    echo "Running ${operation} on ${dataset} with 4o"
    python ./data_gen/gpt4o/translate.py --dataset ${dataset}
    echo "Finished ${operation} on ${dataset} with 4o"
#  done
done
