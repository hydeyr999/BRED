datasets=('xsum' 'squad' 'writingprompts' 'pubmedqa' 'openreview' 'tweets' 'blog')
#operations=('create' 'rewrite' 'summary' 'refine' 'polish' 'expand' 'translate')
operation='translate'

for dataset in ${datasets[@]}; do
#  for operation in ${operations[@]}; do
    echo "Running ${operation} on ${dataset} with deepseek"
    python ./data_gen/deepseek/translate.py --dataset ${dataset}
    echo "Finished ${operation} on ${dataset} with deepseek"
#  done
done
