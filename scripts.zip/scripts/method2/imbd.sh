domains=('xsum' 'pubmedqa' 'squad' 'writingprompts' 'openreview' 'blog' 'tweets')
models=('llama' 'deepseek' 'gpt4o' 'Qwen')
#operations=('create' 'rewrite' 'summary' 'polish' 'refine' 'expand' 'translate')
operations=('translate')
epochs=10
threshold="0.01"
n_sample=250
multilen=0
device='cuda:3'

python detectors/method2/run.py --dataset imbd --mode train --device $device \
--epochs $epochs --threshold $threshold --n_sample $n_sample --imbddata True --translate True

#for operation in ${operations[@]}; do
#  echo "Testing operation: $operation, epochs: $epochs, threshold: $threshold, n_sample: $n_sample"
#  python detectors/method2/run.py --task cross-operation --dataset $operation --mode test \
#  --deberta_model ./detectors/method2/weights/otherdata/deberta_imbd_ep$epochs\_thres$threshold\_n$n_sample\_False \
#  --device $device --epochs $epochs --threshold $threshold --n_sample $n_sample --multilen $multilen --imbddata True
#done

for operation in ${operations[@]}; do
  echo "Testing operation: $operation, epochs: $epochs, threshold: $threshold, n_sample: $n_sample"
  python detectors/method2/run.py --task cross-operation --dataset $operation --mode test \
  --deberta_model ./detectors/method2/weights/otherdata/deberta_imbd_ep$epochs\_thres$threshold\_n$n_sample\_True_sim \
  --device $device --epochs $epochs --threshold $threshold --n_sample $n_sample --multilen $multilen --imbddata True --translate True
done
