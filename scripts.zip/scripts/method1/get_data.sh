domains=('xsum' 'pubmedqa' 'squad' 'writingprompts' 'openreview' 'blog' 'tweets')
models=('llama' 'deepseek' 'gpt4o' 'Qwen')
#operations=('create' 'rewrite' 'summary' 'polish' 'refine' 'expand' 'translate')
operations=('translate')
#languages=('ch' 'de' 'fr')
languages=('ch')
rounds=(2 3)
multilen=0
device='cuda:2'

#python detectors/method1/run.py --dataset HC3 --mode train --device $device \
#--epochs $epochs --threshold $threshold --n_sample $n_sample --imbddata True --translate True

for language in ${languages[@]}; do
for round in ${rounds[@]}; do
  echo "Testing operation: translate, language: $language, round: $round"
  python detectors/method1/run.py --task cross-operation --dataset translate --mode test \
  --language $language --round $round
done
done
