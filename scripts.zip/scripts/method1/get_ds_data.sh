languages=('ch' 'de' 'fr')
#languages=('ch')
round=1
n_sample=250
multilen=0
device='cuda:2'

#python detectors/method1/run.py --dataset HC3 --mode train --device $device \
#--epochs $epochs --threshold $threshold --n_sample $n_sample --imbddata True --translate True

for language in ${languages[@]}; do
#for round in ${round[@]}; do
  echo "Testing operation: translate, language: $language, round: $round"
  python detectors/method1/get_method1_data.py --language $language --round $round
#done
done
