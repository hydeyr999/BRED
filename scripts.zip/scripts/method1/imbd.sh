domains=('xsum' 'pubmedqa' 'squad' 'writingprompts' 'openreview' 'blog' 'tweets')
models=('llama' 'deepseek' 'gpt4o' 'Qwen')
#operations=('create' 'rewrite' 'summary' 'polish' 'refine' 'expand' 'translate')
operations=('translate')
languages=('ch' 'de' 'fr')
round=2
epochs=10
threshold="0.01"
n_sample=250
multilen=0
device='cuda:2'

#python detectors/method1/run.py --dataset HC3 --mode train --device $device \
#--epochs $epochs --threshold $threshold --n_sample $n_sample --imbddata True --translate True

#for operation in ${operations[@]}; do
#  echo "Testing operation: $operation, epochs: $epochs, threshold: $threshold, n_sample: $n_sample"
#  python detectors/method1/run.py --task cross-operation --dataset $operation --mode test \
#  --deberta_model ./detectors/method1/weights/otherdata/deberta_imbd_ep$epochs\_thres$threshold\_n$n_sample\_False \
#  --device $device --epochs $epochs --threshold $threshold --n_sample $n_sample --multilen $multilen --imbddata True
#done

for language in ${languages[@]}; do
for operation in ${operations[@]}; do
  echo "Testing operation: $operation, epochs: $epochs, threshold: $threshold, n_sample: $n_sample, language: $language, round: $round"
  python detectors/method1/run.py --task cross-operation --dataset $operation --mode test \
  --deberta_model ./detectors/method1/weights/otherdata/deberta_HC3_ep$epochs\_thres$threshold\_n$n_sample\_True_bt \
  --device $device --epochs $epochs --threshold $threshold --n_sample $n_sample --multilen $multilen --imbddata True --translate True \
  --language $language --round $round
done
done

#python detectors/method1/run.py --task cross-operation --dataset translate --mode ood --device $device \
#--epochs $epochs --threshold $threshold --n_sample $n_sample --translate True

#for operation in ${operations[@]}; do
#  for domain in ${domains[@]}; do
#    echo "Testing operation: $operation, epochs: $epochs, threshold: $threshold, n_sample: $n_sample"
#    python detectors/method1/run.py --task cross-operation --dataset $operation --mode ood \
#    --deberta_model ./detectors/method1/weights/cross-operation/deberta_translate_ep$epochs\_thres$threshold\_n$n_sample\_$domain\_bt \
#    --device $device --epochs $epochs --threshold $threshold --n_sample $n_sample --multilen $multilen --translate True
#  done
#done
