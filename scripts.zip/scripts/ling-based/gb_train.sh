domains=("xsum" "writingprompts" "pubmedqa" "squad" "openreview" "blog" "tweets")
models=("llama" "deepseek" "gpt4o" "Qwen")
operations=("create" "rewrite" "summary" "refine" "polish" "expand" "translate")
n_sample=500
device="cuda:0"

for domain in ${domains[@]}; do
  echo "Training on $domain, n_sample=$n_sample"
  python detectors/ling-based/ghostbuster.py --task cross-domain --dataset $domain \
  --n_sample $n_sample --device $device --mode train
done

#for model in ${models[@]}; do
#  echo "Training on $model, n_sample=$n_sample"
#  python detectors/ling-based/ghostbuster.py --task cross-model --dataset $model \
#  --n_sample $n_sample --device $device --mode train
#done

for operation in ${operations[@]}; do
  echo "Training on $operation, n_sample=$n_sample"
  python detectors/ling-based/ghostbuster.py --task cross-operation --dataset $operation \
  --n_sample $n_sample --device $device --mode train
done
