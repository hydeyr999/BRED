import json

import pandas as pd
import argparse

datasets_dict = {
                'cross-domain': ['xsum', 'writingprompts','pubmedqa', 'squad', 'openreview', 'blog', 'tweets'],
                'llm-co': ['llama', 'deepseek', 'gpt4o','Qwen'],
                # 'cross-model': ['llama','llama_8b_instruct' ,'gpt4o', 'gpt4o_large', 'Qwen_7b', 'Qwen_8b', 'Qwen', 'deepseek' ],
                'cross-operation': ['create', 'rewrite', 'summary', 'polish', 'refine', 'expand', 'translate'],
                'thinking':['gpt_4o','gpt_5','gpt_5_thinking', 'Qwen', 'Qwen_thinking','deepseek','deepseek_thinking'],
                'op-co':['create', 'rewrite', 'summary', 'refine', 'expand', 'translate']
}

model2s={
    'llama':['deepseek', 'gpt4o', 'Qwen'],
    'deepseek':['llama', 'gpt4o', 'Qwen'],
    'gpt4o':['llama', 'deepseek', 'Qwen'],
    'Qwen':['llama', 'deepseek', 'gpt4o']}

op2s = {
    'create': ['polish', 'expand', 'refine','rewrite'],
    'rewrite': ['polish', 'expand', 'refine'],
    'summary': ['polish', 'rewrite'],
    'refine':['polish','rewrite'],
    'expand':['polish','rewrite'],
    'translate':['polish', 'expand', 'refine', 'rewrite']
}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--task',type=str,default='cross-domain')
    parser.add_argument('--epochs',type=int,default=4)
    parser.add_argument('--n_sample',type=int,default=2000)
    parser.add_argument('--multilen',type=int,default=0)
    parser.add_argument('--detector',type=str,default='deberta')
    parser.add_argument('--threshold',type=float,default=0.0)
    parser.add_argument('--frac',type=float,default=0.2)
    parser.add_argument('--dataset',type=str,default='gpt4o')
    parser.add_argument('--flag',type=str,default='1')
    args = parser.parse_args()
    dfs = []

    # for dataset in datasets_dict[args.task]:
    # for model2 in model2s[args.dataset]:
    for op2 in op2s[args.dataset]:
        # df = pd.read_csv(f'./detectors/llama/results/v1/{args.task}/{args.detector}_{args.dataset}_{op2}_n0.2_{args.flag}_ep4_thres0.0_results.csv')
        with open(f'./detectors/detectanyllm/results/v1/{args.task}/{args.dataset}_{op2}_n0.2_{args.flag}.json', 'r') as f:
            data_dict = json.load(f)
            # print(data_dict)
        # auc = df['auc'].values[0]
        # pr = df['pr'].values[0]
        auc = data_dict['AUROC']
        pr = data_dict['AUPR']
        # auc = data_dict['val_ROC_AUC']
        # pr = data_dict['val_PR_AUC']
        # auc = data_dict['metrics']['roc_auc']
        # pr = data_dict['pr_metrics']['pr_auc']
        # print(auc, pr)
        df = pd.DataFrame({'AUROC': [auc], 'AUPR': [pr]})

        # df['dataset'] = dataset
        # df['model2'] = model2
        df['op2'] = op2
        dfs.append(df)
    df = pd.concat(dfs)
    print(df)