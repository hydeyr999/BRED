domains=("xsum" "writingprompts" "pubmedqa" "squad" "openreview" "blog" "tweets")
models=("llama" "deepseek" "gpt4o" "Qwen")
operations=("create" "rewrite" "summary" "refine" "polish" "expand" "translate")
multilen=0
device='cuda:0'

for domain in ${domains[@]}; do
  echo "Processing domain: $domain"
  python detectors/binoculars/main.py --task cross-domain --dataset $domain
done

for model in ${models[@]}; do
  echo "Processing model: $model"
  python detectors/binoculars/main.py --task cross-model --dataset $model
done

for operation in ${operations[@]}; do
  echo "Processing operation: $operation"
  python detectors/binoculars/main.py --task cross-operation --dataset $operation
done